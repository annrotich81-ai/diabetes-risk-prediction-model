# Publishing this project to GitHub

1. Sign in to GitHub and create a new repository (for example, `diabetes-risk-prediction`).
2. Choose whether the repository should be public or private. For a lecturer's review, confirm whether a public link is required.
3. Extract this project ZIP on your computer and open a terminal in the extracted folder.
4. Run the following commands, replacing the URL with the repository URL shown by GitHub:

```bash
git init
git add .
git commit -m "Add diabetes risk prediction project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

5. Open the repository in a browser and copy its URL.
6. Paste the actual repository URL into the blank GitHub Repository URL line on page 10 of `Project_Report.pdf` before submission.

Do not publish private patient data, passwords, access tokens or other confidential information. The supplied dataset is downloaded from a public source by the Python script and is not bundled in this archive.
